<?php
	 session_start();
?>

<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="login_version_2.css">
  </head>
	<body>
	
	
	<?php
		$mysqli=new mysqli( "localhost",
			 				"sindler.s",
							"kosper1",
							"sindler.s");
		mysqli_set_charset($mysqli,"utf8");
	
		$users = $mysqli->query("SELECT * FROM users");
		$row = $users->fetch_assoc();
		
		if(isset($_POST["Login"])){
			if($_POST['meno']==$row['meno'] and $_POST['heslo']==$row['heslo']){
				$_SESSION['prihlaseni']=1;
			}
			else{
		
				echo "<br> zle prihlasovacie udaje</br>" ;
        }
        }
	     ?>	

	<!--	
   <div class="image_pos">
    <div class="image_1"></div>   
 </div>   
  -->
  <div class="div_main">
    <div class="image_1"></div>
    <br>
	  <form action="stranka_login.php" method="post">
      <div class="centered_user_input">   
  		  <input class="user_input_name" type="text" name="meno" placeholder="Username" ">
  		  <br>
  		  <input class="user_input_password" type="password" name="heslo" placeholder="Password">
  		  <br>
		    <input class="login_button" type="submit" value="Login" name="Login">	
      </div>
		  <br>
	  </form>
  </div>	

	
	
	</body>	
</html>